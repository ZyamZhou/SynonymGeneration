author:  Zyam Zhou

CH-VERSION
1.生成近义词
run generator.py 文件即可。
注意会有红色的warning，是由于模型是在崇新的服务器上用python1.9.0训练的而本地的python版本较低(我的是1.4.0)。

2.英文近义词生成：run generator.py
输入中文生成英文近义词：run ChineseGenerator.py

3.所使用的模型来自
Lei Zhang. Multi-channel reverse dictionary model[J]. Proceedings of the AAAI Conference on Artificial Intelligence,2020, 312--319 


EN-VERSION
1.generate synonym
(1)just run generator.py
(2)NOTE that red warning might occur at the very beginning due to the inconsistent between the
torch version in which the model was trained and is loaded.

2. generate English Synonyms: run generator.py
generate Chinese Synonyms: run ChineseGenerator.py

3. reference
Lei Zhang. Multi-channel reverse dictionary model[J]. Proceedings of the AAAI Conference on Artificial Intelligence,2020, 312--319 


