import torch
from getDef import getDef
import numpy as np
import pandas as pd
import nltk
import time
import logging


# 下载模型所需要的数据
wd_sems = torch.load("./data/wd_sems.pt")
wd_lex = torch.load("./data/wd_lex.pt")
wd_ra = torch.load("./data/wd_ra.pt")
mask_s = torch.load("./data/mask_s.pt")
mask_l = torch.load("./data/mask_l.pt")
mask_r = torch.load("./data/mask_r.pt")



#下载index2word
f = open(r'./data/index2word.txt', 'r', encoding='utf8')
index2word = list(f)
f.close()
index2word = [' '.join([i.strip() for i in word.strip().split('\n')]) for word in index2word ]

#下载模型
model = torch.load("./saved2.pth", map_location='cpu')
model.eval()



file = "./data/words2index.csv"
word2index = pd.read_csv(file)
word2index = word2index.set_index('word')['index'].to_dict()


def getDefIndex(defi):
    def_index = []
    for i in range(len(defi)):
        word = defi[i]
        if word in word2index.keys():
            index = word2index[word]
        else:
            index = 1
        def_index.append(index)
    return def_index


myGetDef = getDef()
while True:
    print("Please wait for 5 seconds.")
    time.sleep(5)
    targetWord = input("Input a word: ")
    #targetWord = "farewell"

    if targetWord == "quit":
        break

    definitions =None
    try:
        definitions = myGetDef.getDefinition(targetWord)
    except:
        print("Request too often! Slow down!")

    if definitions != None:
        targetIndex = word2index[targetWord]
        synonyms = []
        for defi in definitions:
            words = nltk.word_tokenize(defi)
            definition_words = getDefIndex(words)

            word = torch.tensor([int(targetIndex)])
            definition_words = torch.tensor([definition_words])

            indices = model('test', x=definition_words, w=word, ws=wd_sems, wl=wd_lex, wr=wd_ra, msk_s=mask_s,
                            msk_l=mask_l, msk_r=mask_r, mode="rsl")
            predicted = indices[:, :20].detach().cpu().numpy().tolist()

            synonym = np.array(index2word)[predicted[0]]
            synonyms.append(np.array(synonym))
        synonyms = np.hstack(synonyms)
        synonyms = synonyms.tolist()
        print(synonyms)
    else:
        print("Not able to predict.")



