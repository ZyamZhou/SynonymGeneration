import pandas as pd
import json

json_file = "words2.json"
with open (json_file,"r") as json_obj:
    json_data = json.load(json_obj)

data = pd.DataFrame(json_data)

data.to_csv("words2.csv", sep=',',index=False)

