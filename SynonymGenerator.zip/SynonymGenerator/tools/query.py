import pymysql

class Query():
    def __init__(self):
        HOST = 'localhost'  # 主机名
        #HOST = "192.169.128.1"
        USER = 'root'  # 用户名
        PASSWORD = 'root'  # 密码
        DB = 'words'  # 数据库名称
        PORT = 3306  # 端口号
        CHARSET = 'utf8'  # 字符集类型
        try:
            self.conn = pymysql.connect(host=HOST,
                                   port=PORT,
                                   user=USER,
                                   passwd=PASSWORD,
                                   db=DB,
                                   charset=CHARSET)
            print("sucessfully connected")

        except:

            print("Error: unable to connect")

    def fetch(self, sql):
        # 使用cursor()方法获取操作游标
        cursor = self.conn.cursor()
        try:
            cursor.execute(sql)
            # 获取所有记录列表
            results = cursor.fetchall()
            return results
        except:
            print("Error: unable to fecth data")

    def close(self):
        self.conn.close()
