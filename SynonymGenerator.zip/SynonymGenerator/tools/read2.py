import pandas as pd

file = "words2index.csv"


data = pd.read_csv(file)
data = data.set_index('word')['index'].to_dict()

pass