import time
import re
from wordnik import swagger, WordApi


class getDef():
    def __init__(self):
        apiUrl = 'http://api.wordnik.com/v4'
        apiKey = '94c3e2ed22d082fd501070c13d70f57434cdad8a57eaa5475'
        client = swagger.ApiClient(apiKey, apiUrl)
        self.wordApi = WordApi.WordApi(client)

    def getDefinition(self,word):
        definitions = self.wordApi.getDefinitions(word, sourceDictionaries='all')
        word_def = []
        count = 0
        for defi in definitions:
            if defi.text != None:  # sometimes None
                tmp = re.sub('[^a-zA-Z ]', '', (defi.text).lower())
                word_def.append(tmp)
                count += 1
                if count > 4:  # no need too much
                    break
        return word_def

